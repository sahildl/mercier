Here is a template advertising a fictional mobile app or online service. This is an HTML template to edit with [Silex website editor](http://www.silex.me), the open source website builder(free and open source).

It is made with <a href="http://www.silex.me">Silex</a>, and can be hosted anywhere. It is responsive to fit any screen size with the maximum reach.

Silex widgets used:
* [Make text and images appear on scroll](https://github.com/silexlabs/Silex/issues/443)
* hero section

[![screenshot](http://silex-templates.silex.me/smart-simple/screenshot.png)](http://silex-templates.silex.me/smart-simple/)
